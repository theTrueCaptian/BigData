import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class StubMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	public final static IntWritable one = new IntWritable(1);
	public final static IntWritable zero = new IntWritable(0);
	public static String[] SEARCH_STRINGS = new String[]{"hackathon", "Dec", "Chicago", "Java"}; 
	//private Text word = new Text();
	@Override
	public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {

		//Write in initial keys 
		for(String search: SEARCH_STRINGS){
			context.write(new Text(search), zero);

		}
		
	  	String line = value.toString();
		System.out.println(line);
		StringTokenizer tokenizer = new StringTokenizer(line, ", ;:/#-");
        
        //iterating through all the words available in that line and forming the key value pair
		while (tokenizer.hasMoreTokens())
		{
			String word = tokenizer.nextToken();
			//word.set(tokenizer.nextToken());
			System.out.println("word currently processing: "+word);
			//sending to output collector which inturn passes the same to reducer
			int index = -1;
			if((index=isWordInArray(word, SEARCH_STRINGS))!=-1){
				System.out.println("word:"+word+" added 1");
				context.write(new Text(SEARCH_STRINGS[index]), one);
			}
		}
		

	}
	
	public static int isWordInArray(String word, String[] words){
		int index = -1;
		for(int i=0; i<words.length; i++){
			String aword = words[i];
			if(aword.toLowerCase().equals(word.toLowerCase())){
				return i;
			}
		}
		return -1;
	}
  
}

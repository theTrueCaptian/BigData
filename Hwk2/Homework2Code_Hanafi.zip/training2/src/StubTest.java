import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.apache.hadoop.mrunit.mapreduce.MapReduceDriver;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class StubTest {

  /*
   * Declare harnesses that let you test a mapper, a reducer, and
   * a mapper and a reducer working together.
   */
  MapDriver<LongWritable, Text, Text, IntWritable> mapDriver;
  ReduceDriver<Text, IntWritable, Text, IntWritable> reduceDriver;
  MapReduceDriver<LongWritable, Text, Text, IntWritable, Text, IntWritable> mapReduceDriver;

  /*
   * Set up the test. This method will be called before every test.
   */
  @Before
  public void setUp() {

    /*
     * Set up the mapper test harness.
     */
    StubMapper mapper = new StubMapper();
    mapDriver = new MapDriver<LongWritable, Text, Text, IntWritable>();
    mapDriver.setMapper(mapper);

    /*
     * Set up the reducer test harness.
     */
    StubReducer reducer = new StubReducer();
    reduceDriver = new ReduceDriver<Text, IntWritable, Text, IntWritable>();
    reduceDriver.setReducer(reducer);

    /*
     * Set up the mapper/reducer test harness.
     */
    mapReduceDriver = new MapReduceDriver<LongWritable, Text, Text, IntWritable, Text, IntWritable>();
    mapReduceDriver.setMapper(mapper);
    mapReduceDriver.setReducer(reducer);
  }

  /*
   * Test the mapper.
   */
  @Test
  public void testMapper() {

    /*
     * For this test, the mapper's input will be "1 cat cat dog" 
     * TODO: implement
     */
    //assertTrue("Mapper",new StubMapper().map(1, "", new Context());
	String line = "31-Dec-14,3:00PM,‏#Hackatopia,Designers, Developers, Doers, don't miss this upcoming Chicago hackathon 9-Dec-14,5:00PM,‏#Hackatopia,Tribeca Film Hackathon: Code As A New Language For Content Creators";
	System.out.println(line);
	StringTokenizer tokenizer = new StringTokenizer(line, ", ;:/#");
      
    //iterating through all the words available in that line and forming the key value pair
	while (tokenizer.hasMoreTokens())
	{
		String word = tokenizer.nextToken();
		//word.set(tokenizer.nextToken());
		System.out.println("word currently processing: "+word);
		//sending to output collector which inturn passes the same to reducer
		if(StubMapper.isWordInArray(word, StubMapper.SEARCH_STRINGS)!=-1){
			System.out.println("word:"+word+" added 1");
				//context.write(new Text(word), StubMapper.one);
			}
		}
  }

  /*
   * Test the reducer.
   */
  @Test
  public void testReducer() {

    /*
     * For this test, the reducer's input will be "cat 1 1".
     * The expected output is "cat 2".
     * TODO: implement
     */
    fail("Please implement test.");

  }


  /*
   * Test the mapper and reducer working together.
   */
  @Test
  public void testMapReduce() {

    /*
     * For this test, the mapper's input will be "1 cat cat dog" 
     * The expected output (from the reducer) is "cat 2", "dog 1". 
     * TODO: implement
     */
    fail("Please implement test.");

  }
}
